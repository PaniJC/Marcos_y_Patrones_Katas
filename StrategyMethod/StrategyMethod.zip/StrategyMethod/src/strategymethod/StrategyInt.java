
/**
 *
 * @author PaniJC
 */
package strategymethod;

public interface StrategyInt {  
    
    abstract int move(StrategyInt strategy);
  
}
