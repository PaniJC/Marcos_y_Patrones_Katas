/**
 *
 * @author PaniJC
 */
package strategymethod;

public class Fly implements StrategyInt {

    @Override
    public int move(StrategyInt strategy) {
        return 10;
    }
      
    
}
