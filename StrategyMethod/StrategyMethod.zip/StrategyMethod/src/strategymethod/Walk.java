
/**
 *
 * @author PaniJC
 */
package strategymethod;

public class Walk implements StrategyInt {

    @Override
    public int move(StrategyInt strategy) {
        return 1;
    }
  
    
}
